const uThirteen = document.getElementById("thirteen");
console.log(uThirteen);
